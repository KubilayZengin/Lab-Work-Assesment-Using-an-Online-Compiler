public class Buse {
    public static void main(String[] args) {
        System.out.println("Hello!");
    }
}
