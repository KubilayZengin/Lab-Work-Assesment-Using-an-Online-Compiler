import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) {
        try {
            /*
            THE fullPath NEEDS TO BE CHANGED IN EVERY OTHER COMPUTER
             */
            String fullPath = "C:\\Users\\kubil\\IdeaProjects\\Compiler\\";
            // Compile and run Lecturer's Ilker.java code.
            if (compileAndRun(fullPath+"Lecturer", "Ilker", "Ilker.txt") == 0) {
                // Compile and run every java code in Student folder.
                File studentFolder = new File(fullPath+"Student");
                for (File file : studentFolder.listFiles()) {
                    if (file.isFile() && file.getName().endsWith(".java")) {
                        String filename = file.getName().replace(".java", "");
                        int result = compileAndRun(fullPath+"Student", filename, "output_" + filename + ".txt");
                        if (result != 0) {
                            System.out.println(filename + " compilation and run error.");
                            continue;
                        }
                        // Compare with Ilker and print the output.
                        if (compareOutputs("Ilker.txt", "output_" + filename + ".txt")) {
                            System.out.println(filename+" got 100 points.");
                        } else {
                            System.out.println(filename+" got 0 points.");
                        }
                    }
                }
            } else {
                System.out.println("Compilation and run error for Lecturer Ilker.java.");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static int compileAndRun(String folderPath, String className, String outputFileName) throws IOException, InterruptedException {
        Process compileProcess = Runtime.getRuntime().exec("javac " + folderPath + "\\" + className + ".java");
        int compileExitCode = compileProcess.waitFor();

        if (compileExitCode == 0) {
            ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", "java -cp " + folderPath + " " + className + " > " + outputFileName);
            processBuilder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
            processBuilder.redirectError(ProcessBuilder.Redirect.INHERIT);
            Process redirectOutputProcess = processBuilder.start();
            int runExitCode = redirectOutputProcess.waitFor();
            return runExitCode;
        }

        return compileExitCode;
    }

    private static boolean compareOutputs(String output1FileName, String output2FileName) throws IOException {
        String content1 = new String(Files.readAllBytes(Paths.get(output1FileName)));
        String content2 = new String(Files.readAllBytes(Paths.get(output2FileName)));
        return content1.equals(content2);
    }
}
